//+------------------------------------------------------------------+
//| Video_Inspired_Pending_EA.mq5                                    |
//| MT5 Expert Advisor: pending breakout orders + trailing SL        |
//| Approximation based on visible video behavior, not original code. |
//+------------------------------------------------------------------+
#property strict
#property version "1.10"
#property description "Configurable pending-stop EA with trailing stop, spread filter and trade limits."

#include <Trade/Trade.mqh>
CTrade trade;

//--- Order and risk settings
input double InpLots                   = 0.01;
input int    InpEntryDistancePoints    = 300;
input int    InpStopLossPoints         = 300;    // 0 disables initial SL
input int    InpTakeProfitPoints       = 0;      // 0 disables TP
input int    InpMaxPositions           = 2;
input int    InpMaxPendingOrders       = 2;
input int    InpMaxSpreadPoints        = 80;     // 0 disables spread filter
input ulong  InpMagic                  = 30102026;
input int    InpSlippagePoints         = 20;

//--- Trailing-stop settings
input bool   InpUseTrailingStop        = true;
input int    InpTrailingStartPoints    = 150;
input int    InpTrailingDistancePoints = 120;
input int    InpTrailingStepPoints     = 20;

//--- Behavior settings
input bool   InpMaintainBothSides      = true;
input bool   InpDeleteOppositePending  = false;
input bool   InpOnlyOnNewBar           = false;

//--- Optional server-time filter
input bool   InpUseTradingHours        = false;
input int    InpStartHour              = 7;
input int    InpEndHour                = 20;

datetime g_lastBarTime = 0;

//+------------------------------------------------------------------+
int OnInit()
{
   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(InpSlippagePoints);
   trade.SetTypeFillingBySymbol(_Symbol);

   if(InpLots <= 0 || InpEntryDistancePoints <= 0 ||
      InpMaxPositions < 0 || InpMaxPendingOrders < 0 ||
      InpTrailingStartPoints < 0 || InpTrailingDistancePoints <= 0 ||
      InpTrailingStepPoints <= 0)
   {
      Print("EA initialization failed: check input values.");
      return INIT_PARAMETERS_INCORRECT;
   }

   Print("Video-Inspired Pending EA started on ", _Symbol,
         ". Please test in Strategy Tester/demo before live use.");
   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
void OnTick()
{
   // Manage open positions on every tick, even when new orders are
   // restricted to new bars.
   if(InpUseTrailingStop)
      ManageTrailingStops();

   if(InpOnlyOnNewBar)
   {
      datetime barTime = iTime(_Symbol, _Period, 0);
      if(barTime == 0 || barTime == g_lastBarTime)
         return;
      g_lastBarTime = barTime;
   }

   if(!TradingTimeAllowed() || !SpreadAllowed())
      return;

   if(!InpMaintainBothSides)
      return;

   if(CountOurPositions() >= InpMaxPositions)
      return;

   MaintainPendingOrders();
}

//+------------------------------------------------------------------+
bool TradingTimeAllowed()
{
   if(!InpUseTradingHours)
      return true;

   MqlDateTime now;
   TimeToStruct(TimeCurrent(), now);

   if(InpStartHour == InpEndHour)
      return true;

   if(InpStartHour < InpEndHour)
      return (now.hour >= InpStartHour && now.hour < InpEndHour);

   // Session crossing midnight
   return (now.hour >= InpStartHour || now.hour < InpEndHour);
}

//+------------------------------------------------------------------+
bool SpreadAllowed()
{
   if(InpMaxSpreadPoints <= 0)
      return true;

   MqlTick tick;
   if(!SymbolInfoTick(_Symbol, tick))
      return false;

   return ((tick.ask - tick.bid) / _Point <= InpMaxSpreadPoints);
}

//+------------------------------------------------------------------+
double NormalizeLots(double requested)
{
   double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double step   = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);

   if(step <= 0 || minLot <= 0 || maxLot <= 0)
      return 0.0;

   // Do not silently exceed requested risk by rounding up.
   double lots = MathMin(requested, maxLot);
   lots = MathFloor(lots / step + 1e-8) * step;

   if(lots < minLot)
   {
      Print("Requested lot size is below broker minimum. Requested=",
            requested, ", minimum=", minLot);
      return 0.0;
   }

   int digits = 0;
   double s = step;
   while(digits < 8 && MathAbs(s - MathRound(s)) > 1e-8)
   {
      s *= 10.0;
      digits++;
   }
   return NormalizeDouble(lots, digits);
}

//+------------------------------------------------------------------+
int CountOurPositions()
{
   int count = 0;
   for(int i = PositionsTotal() - 1; i >= 0; --i)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(PositionGetString(POSITION_SYMBOL) == _Symbol &&
         (ulong)PositionGetInteger(POSITION_MAGIC) == InpMagic)
         count++;
   }
   return count;
}

//+------------------------------------------------------------------+
int CountOurPendingOrders()
{
   int count = 0;
   for(int i = OrdersTotal() - 1; i >= 0; --i)
   {
      ulong ticket = OrderGetTicket(i);
      if(ticket == 0)
         continue;

      if(OrderGetString(ORDER_SYMBOL) != _Symbol ||
         (ulong)OrderGetInteger(ORDER_MAGIC) != InpMagic)
         continue;

      ENUM_ORDER_TYPE type =
         (ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);

      if(type == ORDER_TYPE_BUY_STOP || type == ORDER_TYPE_SELL_STOP ||
         type == ORDER_TYPE_BUY_STOP_LIMIT || type == ORDER_TYPE_SELL_STOP_LIMIT)
         count++;
   }
   return count;
}

//+------------------------------------------------------------------+
bool HasPendingType(ENUM_ORDER_TYPE wanted)
{
   for(int i = OrdersTotal() - 1; i >= 0; --i)
   {
      ulong ticket = OrderGetTicket(i);
      if(ticket == 0)
         continue;

      if(OrderGetString(ORDER_SYMBOL) != _Symbol ||
         (ulong)OrderGetInteger(ORDER_MAGIC) != InpMagic)
         continue;

      if((ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE) == wanted)
         return true;
   }
   return false;
}

//+------------------------------------------------------------------+
double BrokerMinStopDistance()
{
   long stops  = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL);
   long freeze = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_FREEZE_LEVEL);
   return (double)MathMax(stops, freeze) * _Point;
}

//+------------------------------------------------------------------+
void MaintainPendingOrders()
{
   MqlTick tick;
   if(!SymbolInfoTick(_Symbol, tick))
      return;

   double lots = NormalizeLots(InpLots);
   if(lots <= 0)
      return;

   int pendingCount = CountOurPendingOrders();
   if(pendingCount >= InpMaxPendingOrders)
      return;

   double minGap = BrokerMinStopDistance() + 2.0 * _Point;
   double entryGap = MathMax(InpEntryDistancePoints * _Point, minGap);

   // Buy Stop above Ask
   if(!HasPendingType(ORDER_TYPE_BUY_STOP) &&
      CountOurPendingOrders() < InpMaxPendingOrders &&
      CountOurPositions() < InpMaxPositions)
   {
      double entry = NormalizeDouble(tick.ask + entryGap, _Digits);
      double sl = 0.0, tp = 0.0;

      if(InpStopLossPoints > 0)
         sl = NormalizeDouble(entry - InpStopLossPoints * _Point, _Digits);
      if(InpTakeProfitPoints > 0)
         tp = NormalizeDouble(entry + InpTakeProfitPoints * _Point, _Digits);

      ResetLastError();
      if(!trade.BuyStop(lots, entry, _Symbol, sl, tp, ORDER_TIME_GTC, 0,
                        "VideoEA BuyStop"))
         Print("Buy Stop failed. Retcode=", trade.ResultRetcode(),
               " ", trade.ResultRetcodeDescription(),
               " LastError=", GetLastError());
   }

   // Sell Stop below Bid
   if(!HasPendingType(ORDER_TYPE_SELL_STOP) &&
      CountOurPendingOrders() < InpMaxPendingOrders &&
      CountOurPositions() < InpMaxPositions)
   {
      double entry = NormalizeDouble(tick.bid - entryGap, _Digits);
      double sl = 0.0, tp = 0.0;

      if(InpStopLossPoints > 0)
         sl = NormalizeDouble(entry + InpStopLossPoints * _Point, _Digits);
      if(InpTakeProfitPoints > 0)
         tp = NormalizeDouble(entry - InpTakeProfitPoints * _Point, _Digits);

      ResetLastError();
      if(!trade.SellStop(lots, entry, _Symbol, sl, tp, ORDER_TIME_GTC, 0,
                         "VideoEA SellStop"))
         Print("Sell Stop failed. Retcode=", trade.ResultRetcode(),
               " ", trade.ResultRetcodeDescription(),
               " LastError=", GetLastError());
   }
}

//+------------------------------------------------------------------+
//| Trailing SL: follows favorable movement and never loosens.       |
//+------------------------------------------------------------------+
void ManageTrailingStops()
{
   MqlTick tick;
   if(!SymbolInfoTick(_Symbol, tick))
      return;

   double minGap = BrokerMinStopDistance();
   int startPts = MathMax(1, InpTrailingStartPoints);
   int trailPts = MathMax(1, InpTrailingDistancePoints);
   int stepPts  = MathMax(1, InpTrailingStepPoints);

   for(int i = PositionsTotal() - 1; i >= 0; --i)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(PositionGetString(POSITION_SYMBOL) != _Symbol ||
         (ulong)PositionGetInteger(POSITION_MAGIC) != InpMagic)
         continue;

      ENUM_POSITION_TYPE side =
         (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      double oldSL     = PositionGetDouble(POSITION_SL);
      double oldTP     = PositionGetDouble(POSITION_TP);
      double newSL     = 0.0;

      if(side == POSITION_TYPE_BUY)
      {
         double profitPts = (tick.bid - openPrice) / _Point;
         if(profitPts < startPts)
            continue;

         newSL = tick.bid - trailPts * _Point;
         double highestAllowed = tick.bid - minGap;
         if(newSL > highestAllowed)
            newSL = highestAllowed;
         newSL = NormalizeDouble(newSL, _Digits);

         // Existing Buy SL may only move up.
         if(oldSL > 0 && newSL < oldSL + stepPts * _Point)
            continue;
         if(newSL <= 0 || newSL >= tick.bid)
            continue;
      }
      else if(side == POSITION_TYPE_SELL)
      {
         double profitPts = (openPrice - tick.ask) / _Point;
         if(profitPts < startPts)
            continue;

         newSL = tick.ask + trailPts * _Point;
         double lowestAllowed = tick.ask + minGap;
         if(newSL < lowestAllowed)
            newSL = lowestAllowed;
         newSL = NormalizeDouble(newSL, _Digits);

         // Existing Sell SL may only move down.
         if(oldSL > 0 && newSL > oldSL - stepPts * _Point)
            continue;
         if(newSL <= tick.ask)
            continue;
      }
      else
         continue;

      ResetLastError();
      if(!trade.PositionModify(ticket, newSL, oldTP))
      {
         Print("Trailing SL failed for position #", ticket,
               ". Retcode=", trade.ResultRetcode(),
               " ", trade.ResultRetcodeDescription(),
               " LastError=", GetLastError());
      }
   }
}

//+------------------------------------------------------------------+
//| Optional: delete opposite pending order after a new entry fills. |
//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction &trans,
                        const MqlTradeRequest &request,
                        const MqlTradeResult &result)
{
   if(!InpDeleteOppositePending)
      return;
   if(trans.type != TRADE_TRANSACTION_DEAL_ADD || trans.deal == 0)
      return;
   if(!HistoryDealSelect(trans.deal))
      return;

   if(HistoryDealGetString(trans.deal, DEAL_SYMBOL) != _Symbol ||
      (ulong)HistoryDealGetInteger(trans.deal, DEAL_MAGIC) != InpMagic)
      return;

   ENUM_DEAL_ENTRY entry =
      (ENUM_DEAL_ENTRY)HistoryDealGetInteger(trans.deal, DEAL_ENTRY);
   if(entry != DEAL_ENTRY_IN)
      return;

   ENUM_DEAL_TYPE dealType =
      (ENUM_DEAL_TYPE)HistoryDealGetInteger(trans.deal, DEAL_TYPE);

   ENUM_ORDER_TYPE opposite =
      (dealType == DEAL_TYPE_BUY) ? ORDER_TYPE_SELL_STOP : ORDER_TYPE_BUY_STOP;

   for(int i = OrdersTotal() - 1; i >= 0; --i)
   {
      ulong ticket = OrderGetTicket(i);
      if(ticket == 0)
         continue;

      if(OrderGetString(ORDER_SYMBOL) != _Symbol ||
         (ulong)OrderGetInteger(ORDER_MAGIC) != InpMagic)
         continue;

      if((ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE) == opposite)
      {
         if(!trade.OrderDelete(ticket))
            Print("Could not delete opposite pending order #", ticket,
                  ". ", trade.ResultRetcodeDescription());
      }
   }
}
//+------------------------------------------------------------------+
