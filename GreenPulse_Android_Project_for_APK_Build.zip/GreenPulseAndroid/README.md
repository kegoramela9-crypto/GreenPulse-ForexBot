# GreenPulse Forex Bot Android starter

This is an Android WebView wrapper for the included local dashboard prototype. It is not a live trading app yet; its dashboard controls do not connect to MT5 or place trades.

## Build APK using a phone and GitHub Actions
1. Sign in to GitHub and create a new repository (for example, `GreenPulseForexBot`).
2. Upload the contents of this folder to the repository root, preserving folder structure. You can upload the ZIP by extracting it first in a file manager.
3. Open the repository's **Actions** tab. If prompted, enable workflows.
4. Choose **Build GreenPulse APK** and tap **Run workflow**.
5. When the run finishes successfully, open it and download the artifact named `GreenPulse-ForexBot-debug-apk`.
6. Extract the artifact ZIP to find `app-debug.apk`, then tap it on your phone to install. Android may ask you to allow installs from that source.

The APK is a debug build for testing, not a Play Store release. Do not connect it to a live account until a secure MT5 bridge, authentication, risk controls, and demo testing are implemented.
